import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(p, 'utf8');

test('Tools menu opens with no Quick Access section and a persistent visible search field', () => {
  const html = read('index.html');
  const start = html.indexOf('id="screen-tools"');
  const end = html.indexOf('id="screen-favorites"', start);
  const tools = html.slice(start, end);
  assert.ok(start >= 0 && end > start);
  assert.doesNotMatch(tools, /Quick Access|Quick actions|quick-access/i);
  assert.match(tools, /id="tools-search-panel"/);
  assert.doesNotMatch(tools, /id="tools-search-panel" hidden/);
  assert.match(tools, /id="tools-category-list"/);
  assert.match(html, /id="btn-tools-search"[^>]*aria-label="Focus tool search"/);
});

test('all 17 dedicated tool cards exist once; Scientific opens the existing scientific engine', () => {
  const html = read('index.html');
  const start = html.indexOf('id="premium-tools-grid"');
  const end = html.indexOf('</div>', start);
  const grid = html.slice(start, end);
  const ids = [...grid.matchAll(/data-tool-screen="([a-z]+)"/g)].map(m => m[1]);
  assert.equal(ids.length, 17);
  assert.equal(new Set(ids).size, 17);
  for (const id of ids.filter(id => id !== 'scientific')) assert.match(html, new RegExp(`id="screen-${id}"`), `missing screen ${id}`);
  assert.match(html, /id="screen-scientific"/);
  assert.doesNotMatch(html, /id="sci-modal-overlay"/);
  assert.doesNotMatch(grid, /data-tool-screen="(?:calc|settings)"/);
});

test('header search focuses the persistent field and filters combine with category chips', () => {
  const js = read('assets/js/app.js');
  assert.match(js, /input\?\.focus\(\{ preventScroll: true \}\)/);
  assert.match(js, /activeToolCategory/);
  assert.match(js, /queryMatch && categoryMatch/);
  assert.match(js, /event\.key === 'Escape'/);
});

test('new premium menu CSS is compiled into Android web bundle and cache-busted', () => {
  const html = read('index.html');
  const builder = read('scripts/prepare-android-web.mjs');
  const css = read('assets/css/app.css');
  const sw = read('service-worker.js');
  assert.match(html,/assets\/css\/app\.css/);
  assert.match(builder,/assets\/css\/app\.css/);
  assert.match(css, /approved Tools reference implemented in the real app/);
  assert.match(css, /tools-category-chip/);
  assert.match(sw, /sa-calculator-v98-63-10-clean-runtime-v9863917/);
});

test('release identity is synchronized across package, manifest and workflow', () => {
  const pkg = JSON.parse(read('package.json'));
  const manifest = JSON.parse(read('manifest.webmanifest'));
  const workflow = read('.github/workflows/main.yml');
  assert.equal(pkg.version, '1.98.65-v98.63.9.17');
  assert.equal(manifest.version, '1.98.65-v98.63.9.17');
  assert.match(workflow, /1\.98\.65-v98\.63\.9\.17/);
  assert.match(workflow, /1098065/);
});
