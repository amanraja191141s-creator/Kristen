import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const css=fs.readFileSync('assets/css/app.css','utf8');
const html=fs.readFileSync('index.html','utf8');
const patch=css.slice(css.lastIndexOf('v98.63.9.27'));
test('scientific matrix is full-width pink 4x4 keypad like first reference video',()=>{
 assert.match(patch,/scientific-drawer\.is-open[\s\S]*top:36%[\s\S]*height:64%[\s\S]*width:100%/);
 assert.match(patch,/scientific-function-grid[\s\S]*grid-template-columns:repeat\(4,minmax\(0,1fr\)\)[\s\S]*grid-template-rows:repeat\(4,minmax\(0,1fr\)\)/);
 assert.match(patch,/background:#ef5b91/); assert.match(patch,/font-size:clamp\(18px,5\.1vw,27px\)/);
});
test('scientific alternate page fills keypad band and floating plus remains accessible',()=>{
 assert.match(patch,/scientific-more-functions:not\(\[hidden\]\)[\s\S]*inset:0[\s\S]*grid-template-columns:repeat\(4,minmax\(0,1fr\)\)/);
 assert.match(patch,/sci-more-toggle[\s\S]*width:52px[\s\S]*background:#168cff/);
 assert.match(patch,/scientific-overlay-open[\s\S]*visibility:hidden[\s\S]*scientific-drawer\.is-open/);
});
test('tools sections stack vertically and tool cards use 3 columns with full scrollable tail',()=>{
 assert.match(patch,/tools-reference-groups[\s\S]*display:block[\s\S]*overflow-y:auto/);
 assert.match(patch,/tools-reference-grid[\s\S]*grid-template-columns:repeat\(3,minmax\(0,1fr\)\)/);
 assert.match(patch,/premium-tool-name[\s\S]*overflow:visible[\s\S]*overflow-wrap:anywhere/);
 assert.match(html,/id="premium-tools-grid"/);
});
test('tool cards are not clipped by inner grid or hidden arrow grid layout',()=>{
 assert.match(patch,/premium-tool-card[\s\S]*min-height:96px[\s\S]*overflow:visible/);
 assert.match(patch,/premium-tool-arrow[\s\S]*display:none/);
 assert.match(patch,/padding:0 12px calc\(28px\s*\+\s*env\(safe-area-inset-bottom,0px\)\)/);
});
test('primary sinh cosh tanh keys are not suppressed from the reference matrix',()=>{
 assert.match(patch,/button\[data-sci-insert="sinh\("[\s\S]*display:flex!important/);
 assert.match(patch,/button\[data-sci-insert="cosh\("[\s\S]*display:flex!important/);
 assert.match(patch,/button\[data-sci-insert="tanh\("[\s\S]*display:flex!important/);
});
