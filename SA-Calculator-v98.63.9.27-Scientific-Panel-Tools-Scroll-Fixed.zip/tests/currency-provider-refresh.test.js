'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '..', 'assets/js/app.js'), 'utf8');
function extract(name) {
  const start = source.indexOf(`function ${name}(`) >= 0 ? source.indexOf(`function ${name}(`) : source.indexOf(`async function ${name}(`);
  assert.notEqual(start, -1, `${name} not found`);
  const open = source.indexOf('{', start); let depth = 0;
  for (let i = open; i < source.length; i++) {
    if (source[i] === '{') depth++;
    else if (source[i] === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  throw new Error(`Could not extract ${name}`);
}

test('refresh uses newer 13-Nov observation instead of complete but older 12-Nov Fawaz table', async () => {
  const today = new Date().toISOString().slice(0, 10);
  const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
  const fawaz = { date: yesterday, usd: { cny: 6.70, inr: 94.0 } };
  const syntheticCode = i => `A${String.fromCharCode(65 + Math.floor(i / 26))}${String.fromCharCode(65 + (i % 26))}`;
  for (let i = 0; i < 105; i++) fawaz.usd[syntheticCode(i).toLowerCase()] = i + 1;
  const openRates = { CNY: 6.68, INR: 94.08 };
  for (let i = 0; i < 45; i++) openRates[syntheticCode(i)] = i + 1;
  const openEr = { result: 'success', base_code: 'USD', time_last_update_utc: `${today} 00:02:31 +0000`, rates: openRates };
  const frankfurter = Array.from({ length: 20 }, (_, i) => ({ base: 'USD', quote: syntheticCode(i), rate: i + 1, date: yesterday }));
  const calls = [];
  const responses = new Map([
    ['https://open.er-api.com/v6/latest/USD', openEr],
    ['https://api.frankfurter.dev/v2/rates?base=USD&expand=providers', frankfurter],
    ['https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.min.json', fawaz]
  ]);
  const context = {
    Date, Number, String, Object, Array, Set, Map, Error, Math, URL,
    NON_CURRENCY_CODES: new Set(),
    fetchWithTimeout: async url => { calls.push(url); if (!responses.has(url)) throw new Error(`Unexpected URL ${url}`); return responses.get(url); }
  };
  const names = ['validateCurrencyRateDate', 'normalizeCurrencyApiRates', 'normalizeOpenExchangeRates', 'normalizeFrankfurterV2Rates', 'mergeCurrencyRateBundles', 'fetchCurrencyRateBundle'];
  const fetchStart = source.indexOf('async function fetchCurrencyRateBundle(');
  const fetchEnd = source.indexOf('\nfunction getCurrencyPairSources(', fetchStart);
  const fetchFunction = source.slice(fetchStart, fetchEnd);
  vm.runInNewContext(`${names.slice(0, -1).map(extract).join('\n')}\n${fetchFunction}; globalThis.run=fetchCurrencyRateBundle;`, context);
  const result = await context.run(['CNY', 'INR']);
  assert.deepEqual(calls, [
    'https://api.frankfurter.dev/v2/rates?base=USD&expand=providers',
    'https://open.er-api.com/v6/latest/USD',
    'https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.min.json'
  ]);
  assert.equal(result.rateDates.CNY, today);
  assert.equal(result.rateDates.INR, today);
  assert.equal(result.rates.CNY, 6.68);
  assert.equal(result.rates.INR, 94.08);
  assert.equal(result.rateSources.CNY, 'Open ER-API');
  assert.deepEqual(Array.from(result.missingRequired), []);
});
