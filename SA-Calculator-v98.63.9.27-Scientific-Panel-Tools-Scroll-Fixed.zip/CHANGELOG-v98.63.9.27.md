# Changelog — v98.63.9.27


- Reworked the scientific function panel to occupy the calculator keypad band, matching the first supplied reference video.
- Restored 4x4 text-only pink scientific keys, including INV, primary hyperbolic functions, inverse hyperbolic functions, powers, cube root and More toggle.
- Expanded-function overlay fills the scientific keypad region without clipping; plus control remains floating and tappable.
- Corrected tools catalogue to vertically stacked groups and a three-column card layout with wrapped names and independently scrollable content.
- Added release tests for the keypad matrix, expanded functions, tools layout and clipped-card regression.
- Updated package/PWA/Android/workflow release identity and cache namespace.
