# QA Results — v98.63.9.27

- Release suite: **65/65 passed**.
- Web bundle build: pass (13 required assets).
- Main app JS syntax: pass.
- Service worker syntax: pass.
- Scientific panel: corrected full-width keypad-band overlay; pink 4x4 reference layout; no display/toolbar duplication; 3 hyperbolic keys explicitly retained; alternate function overlay and plus action are tested.
- Other Calculator: grouped sections now flow vertically; inner tiles use 3 columns; labels can wrap; catalogue scroll area is separated from bottom navigation.
- Unit picker: header/search and options scrolling remain independently styled.
- Version: `1.98.74-v98.63.9.27`; Android versionCode `1098075`.
- Workflow and standalone YAML are identical copies of `.github/workflows/main.yml`.
- APK compilation, physical-device rendering/touch performance, and OEM-specific gesture behavior remain unverified in this environment.
