# Changelog — SA Calculator v98.63

## v98.63.5 — currency picker, live conversion and bottom dock cleanup (2026-11-19)
- Removed the redundant Currency Converter manual Convert button; amount edits, currency selection and swap continue to recalculate automatically.
- Prevented the Android soft keyboard from opening automatically when the currency picker opens. Search remains available on explicit tap.
- Hardened currency picker option rows as full-width, vertically stacked, independently scrollable controls with bounded labels.
- Simplified the visible exchange-rate card to one primary quote; duplicate status and refresh timestamps remain available to assistive technology.
- Unified the five-item bottom navigation dock across screens and included Android bottom safe-area space exactly once.
- Migrated the service-worker cache namespace so installed clients fetch the updated interface.

## v98.63.4 — marked screenshot cleanup
- Bounded currency picker header and structured option rows.
- Removed duplicate visible exchange-rate status and refresh timestamps.
- Removed extra bottom dock safe-area reservation.

## v98.63.3 — release integrity correction
- Fixed release verification version identity and synchronized workflow label.

## v98.63.2 — Android recording fixes
- Corrected currency flag rendering, picker sizing, History card layout and Tools toolbar behavior.
- Improved scroll clearance above the persistent dock.

## v98.63.1 — layout hotfix
- Compact Home keypad, improve expression/preview sizing and refine Tools/Favorites layouts.

## v98.63 — clean calculator-only source
- Retained calculator, scientific calculator, History, Favorites, Tools, Settings, localization and Android workflow.

## v98.63.6 — Android bottom dock and currency picker final correction
- Removed the duplicate bottom safe-area reservation from the five-tab dock; navigation targets now stretch through the full dock row without an extra blank band.
- Rebuilt currency picker layout as a fixed title row, optional search field, and vertically scrolling full-width currency option rows.
- Ensured currency search is not focused on picker open, preventing automatic Android keyboard/IME display.
- Explicitly removed the hidden currency keypad from layout flow so it cannot reserve phantom space.
- Added regression coverage for the reported keyboard/picker and bottom-gap defects.
- Preserved calculator calculations, currency conversion, currency search, swap, rate refresh, and stable Android package identity.
