# Marked screenshot review — v98.63.5

## Screenshot 1 — currency picker / keyboard
- Removed automatic focus from the currency search input when the picker opens.
- The picker now opens with the currency list visible; the soft keyboard should open only after the user taps Search.
- Kept the heading constrained to one line and each currency option as a full-width stacked row with a stable flag, name, code/country metadata and selection mark.
- Kept the options list vertically scrollable and bounded by the visual viewport.

## Screenshot 2 — Currency Converter Convert button and rate panel
- Removed the manual `Convert` button from the Currency Converter markup and removed its click handler.
- Live conversion remains connected to amount keypad edits, source/target currency changes, swap, precision changes and normal screen recalculation.
- Kept the primary exchange-rate quote visible; duplicate provider/status and refresh-time details remain available to assistive technology but do not occupy extra visual lines.
- Preserved manual rate refresh as a separate, intentional refresh control.

## Screenshot 3 — bottom navigation gap
- Unified the five-tab dock as a single flex child at the bottom of the app shell.
- The dock consumes the Android bottom safe-area inset once and paints its background through that inset; tab controls remain above the system gesture/navigation hit area.
- Applied the same shared dock rule to Home, Tools, History, Favorite, Settings and tool destinations.

## Validation boundaries
- Automated source and web-bundle regression tests pass.
- Physical Android installation, screenshot comparison on the target Vivo device, live currency-provider verification and performance profiling have not been performed in this environment.
