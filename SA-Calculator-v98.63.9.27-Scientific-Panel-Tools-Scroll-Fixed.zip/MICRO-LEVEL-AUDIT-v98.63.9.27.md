# Micro-level audit — v98.63.9.27


## Based on observed recording defects

- Scientific matrix was visually compressed due competing late CSS overrides and partial panel sizing.
- Scientific keys lacked the first-video pink, unboxed 4x4 layout; primary hyperbolic keys were suppressed by a legacy rule.
- Additional-function panel inset/height rules could make the panel cramped or clipped.
- Tools screen had nested/side-by-side group flow and 2-column inner cards, making catalogue rows appear clipped near the fixed navigation.

## Corrections
- Final CSS overrides use a 36% display / 64% keypad band and a full-width pink scientific panel.
- Scientific matrix uses 4 equal columns and rows, unboxed labels, stable centered alignment, and responsive text sizing.
- INV, sinh/cosh/tanh, i, inverse-hyperbolic, cube-root, powers and More key are retained in the main 4x4 grid.
- More panel fills the keypad band; the close control is not allowed to consume a separate cell.
- Tools groups stack; card grids use 3 columns; names wrap; cards remain visible; the scroll container gets bottom breathing room.
- Updated release identity and service-worker cache to avoid stale assets.

## Limitations
CSS/source regression tests do not prove device-specific rendering. Verify the generated Android app on the target device for screen sizes, touch, scrolling and performance.
